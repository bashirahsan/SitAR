//
//  LocationTextAnnotationNode.swift
//  testing
//
//  Created by Faraz on 12/10/19.
//  Copyright © 2019 Anthrax.inc. All rights reserved.
//

import Foundation

import UIKit
import SceneKit
import ARKit
import ARCL
import CoreLocation
public class LocationTextAnnotationNode: LocationNode {
    
    // image and text that are displayed by the child nodes
  //  public var image: UIImage
    public var text: String
    
    // child nodes
   // public var imageAnnotationNode: SCNNode
    public var textAnnotationNode: SCNNode

    public init(location: CLLocation?, text: String) {
        self.text = text

        textAnnotationNode = SCNNode()
        super.init(location: location)

    }
    public func update() {
     


        
        // create the child node that holds the location's name
        let textShape = SCNText(string: text, extrusionDepth: 1)
        //textShape.font=UIFont.systemFont(ofSize: 1)
        textShape.firstMaterial!.diffuse.contents = UIColor.white
        textShape.firstMaterial!.specular.contents = UIColor.white
        textShape.firstMaterial!.lightingModel = .phong
        textShape.font = UIFont(name: "Arial",size: 1000)

        textShape.alignmentMode = CATextLayerAlignmentMode.center.rawValue


        textAnnotationNode = SCNNode()
        textAnnotationNode.geometry = textShape

       
        
        // initializer ARCL's LocationNode
        scaleRelativeToDistance = false
        self.scaleRelativeToDistance=false
        // apply a billboard constraint so the parent node, so it always faces the user
        let billboardConstraint = SCNBillboardConstraint()
        billboardConstraint.freeAxes = SCNBillboardAxis.Y
        constraints = [billboardConstraint]
        
        // add the child nodes
        addChildNode(textAnnotationNode)
    
        
        
//        // center text correctly around (x) and below (y) origin (SCNText's origins in in the bottom left corner)
//        let (min, max) = (textAnnotationNode.boundingBox.min, textAnnotationNode.boundingBox.max)
//                  let dx = min.x + 0.5 * (max.x - min.x)
//                  let dy = min.y + 3.5 * (max.y - min.y)
//                  let dz = min.z + 0.5 * (max.z - min.z)
//        textAnnotationNode.pivot = SCNMatrix4MakeTranslation(dx, dy, dz)
//
//      //  print("Object made")
//
   }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
