//
//  Soldier.swift
//  testing
//
//  Created by Faraz on 3/3/20.
//  Copyright © 2020 Anthrax.inc. All rights reserved.
//

import Foundation
