#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_testing_testingUITests : NSObject
@end
@implementation PodsDummy_Pods_testing_testingUITests
@end
