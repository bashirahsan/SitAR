#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_testingTests : NSObject
@end
@implementation PodsDummy_Pods_testingTests
@end
