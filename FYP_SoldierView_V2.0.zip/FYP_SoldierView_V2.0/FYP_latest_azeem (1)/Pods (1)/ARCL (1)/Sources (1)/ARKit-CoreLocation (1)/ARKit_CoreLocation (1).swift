struct ARKit_CoreLocation {
    // swiftlint:disable:previous type_name
    var text = "Hello, World!"
}
